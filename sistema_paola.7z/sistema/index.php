<?php
header("location: /sistema/user");
exit;
?>