<a href="/programacao2-/sistema/admin/index.php" style="color: black;">Index</a>
<a href="/programacao2-/sistema/admin/prod/">Produto</a>
<a href="/programacao2-/sistema/admin/categoria/">Categorias</a>
<a href="/programacao2-/sistema/admin/logout.php" style="color: black;">Logout</a>
 