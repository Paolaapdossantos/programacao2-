<?php
include("./config.inc.php");
include("./session.php");
validaSessao();
include ("../header.php");
include("./menu.php");

?>
Admin
<?php
include  ("../footer.php");
?>
