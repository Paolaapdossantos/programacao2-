<?php
include("./config.inc.php");
include("./session.php");
validaSessao();
logout();
exit;
?>