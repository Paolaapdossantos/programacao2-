
<div style="float: right; color: gray; font: 10pt/12pt; font-style: italic;">
 Direitos reservados a mim 💋
</div>
</body>
</html>