<?php

$bodyBG= "pink";

?>