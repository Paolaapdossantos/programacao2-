<html>
<head>
    <title>Direitos reservados a Lumora 💋</title>
</head>
<body style="background-color: <?=$bodyBG;?>;">
    <img src ="/programacao2-/sistema/logo_fatec_cor.png" width="200" heigth="150"/>
    <h1> LUMORA 💋</h1>